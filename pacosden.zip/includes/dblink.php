<?php

$connection = new Mysqli;
$connection->connect("localhost","root","root","pacosden");
if($connection){
    file_put_contents("log.txt","connection successful",FILE_APPEND);
}

$con = mysqli_connect("localhost","root","root","pacosden");

